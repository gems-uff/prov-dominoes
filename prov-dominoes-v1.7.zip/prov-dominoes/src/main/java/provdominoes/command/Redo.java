package provdominoes.command;

public interface Redo {
	
	public void updateCommandManager(CommandManager cmd, boolean reproducing, boolean scripting);

}
